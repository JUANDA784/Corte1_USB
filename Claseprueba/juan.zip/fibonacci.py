n = int(input('¿Cuantos numeros desea generar de la serie de fibonacci?'))

s=2
for i in range(0,n):
    i+=1
    s=s+1 
    a=s+i
    print(a)
